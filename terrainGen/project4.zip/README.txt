You do have to run this using a webserver
Features:
	Blending the water
	Random terrain generation
	Skybox
